import { card } from "../assets";
import styles, { layout } from "../style";
import Button from "./Button";

const CardDeal = () => (
  <section className={layout.section}>
    <div className={layout.sectionInfo}>
      <h2 className={styles.heading2}>
        Zoek een betere kaartdeal <br className="sm:block hidden" /> In enkele stappen.
      </h2>
      <p className={`${styles.paragraph} max-w-[470px] mt-5`}>
        Door op "Start hier" te klikken zorgen wij ervoor dat u de beste kaartdeal krijgt die er op internet te vinden is.
      </p>

      <Button styles={`mt-10`} />
    </div>

    <div className={layout.sectionImg}>
      <img src={card} alt="billing" className="w-[100%] h-[100%]" />
    </div>
  </section>
);

export default CardDeal;