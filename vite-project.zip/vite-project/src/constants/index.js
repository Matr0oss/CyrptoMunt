import { people01, people02, people03, facebook, instagram, linkedin, twitter, airbnb, binance, coinbase, dropbox, send, shield, star  } from "../assets";

export const navLinks = [
  {
    id: "home",
    title: "Home",
  },
  {
    id: "features",
    title: "Functies",
  },
  {
    id: "product",
    title: "Product",
  },
  {
    id: "clients",
    title: "Klanten",
  },
];

export const features = [
  {
    id: "feature-1",
    icon: star,
    title: "Beloningen",
    content:
      "De beste creditcards bieden een aantal verleidelijke combinaties van promoties en prijzen",
  },
  {
    id: "feature-2",
    icon: shield,
    title: "100% beveiligd",
    content:
      "We nemen proactieve stappen om ervoor te zorgen dat uw informatie en transacties veilig zijn.",
  },
  {
    id: "feature-3",
    icon: send,
    title: "Saldo overboeking",
    content:
      "Een saldo-overdracht creditcard kan u veel geld besparen in rentelasten.",
  },
];

export const feedback = [
  {
    id: "feedback-1",
    content:
      "Geld is slechts een hulpmiddel. Hij brengt je waar je maar wilt, maar vervangt jou niet als bestuurder.",
    name: "Herman Jensen",
    title: "Founder & Leader",
    img: people01,
  },
  {
    id: "feedback-2",
    content:
      "Geld maakt je leven makkelijker. Als je het geluk hebt om het te hebben, heb je geluk.",
    name: "Steve Mark",
    title: "Founder & Leader",
    img: people02,
  },
  {
    id: "feedback-3",
    content:
      "Het zijn meestal mensen in de geldzaken, financiën en internationale handel die echt rijk zijn.",
    name: "Kenn Gallagher",
    title: "Founder & Leader",
    img: people03,
  },
];

export const stats = [
  {
    id: "stats-1",
    title: "Gebruikers",
    value: "3800+",
  },
  {
    id: "stats-2",
    title: "Vertrouwd door bedrijven",
    value: "230+",
  },
  {
    id: "stats-3",
    title: "Transacties",
    value: "$280M+",
  },
];

export const footerLinks = [
  {
    title: "Useful Links",
    links: [
      {
        name: "How it Works",
        link: "https://www.hoobank.com/how-it-works/",
      },
      {
        name: "Create",
        link: "https://www.hoobank.com/create/",
      },
      {
        name: "Terms & Services",
        link: "https://www.hoobank.com/terms-and-services/",
      },
    ],
  },
  {
    title: "Community",
    links: [
      {
        name: "Help Desk",
        link: "https://www.hoobank.com/help-center/",
      },
      {
        name: "Newsletters",
        link: "https://www.hoobank.com/newsletters/",
      },
    ],
  },
  {
    title: "Partner",
    links: [
      {
        name: "Our Partner",
        link: "https://www.hoobank.com/our-partner/",
      },
      {
        name: "Become a Partner",
        link: "https://www.hoobank.com/become-a-partner/",
      },
    ],
  },
];

export const socialMedia = [
  {
    id: "social-media-1",
    icon: instagram,
    link: "https://www.instagram.com/",
  },
  {
    id: "social-media-2",
    icon: facebook,
    link: "https://www.facebook.com/",
  },
  {
    id: "social-media-3",
    icon: twitter,
    link: "https://www.twitter.com/",
  },
  {
    id: "social-media-4",
    icon: linkedin,
    link: "https://www.linkedin.com/",
  },
];

export const clients = [
  {
    id: "client-1",
    logo: airbnb,
  },
  {
    id: "client-2",
    logo: binance,
  },
  {
    id: "client-3",
    logo: coinbase,
  },
  {
    id: "client-4",
    logo: dropbox,
  },
];